from tkinter import *
import pickle
import winsound

# Editor Functions
def swap(frame):
    global QsToday
    global dailyGoal
    global profileData
    global username

    try:
        pickle_in = open("dict.pickle", "rb")
        example = pickle.load(pickle_in)
        dailyGoal = example["daily"]
        username = example["name"]

        nameLabel["text"] = "  Username: " + username
        goalLabel["text"] = "  Daily Goal: " + dailyGoal
        startLabel["text"] = "Welcome " + username
    except FileNotFoundError:
        username = username

    frame.tkraise()
    if int(QsToday) >= int(dailyGoal):
        QsToday = QsToday
    else:
        totalQ["text"] = "  Questions Answered: " + str(QsToday)


def createEditor():
    global username

    new = Toplevel(profileFrame)
    chngName = Entry(new,  font=("Centaur", 15))
    chngName.place(relx=0.1, rely=0.2, relwidth=0.8)

    chngGoal = Entry(new,  font=("Centaur", 15))
    chngGoal.place(relx=0.1, rely=0.55, relwidth=0.8)

    Label(new, text="Enter New Name", font=("Centaur", 15)).place(relx=0.16, rely=0.05)
    Label(new, text="Enter New Goal", font=("Centaur", 15)).place(relx=0.16, rely=0.4)

    save = Button(new, text="Save", font=("Centaur",13), command=lambda: getProfileData(chngName.get(), chngGoal.get()))
    save.place(relx=0.39, rely=0.73)


def getProfileData(name, goal):
    global username
    global dailyGoal
    global profileData

    if len(name) == 0:
        username = str(username)
    else:
        username = str(name)

    if len(goal) == 0:
        dailyGoal = str(dailyGoal)
    else:
        dailyGoal = str(goal)

    nameLabel["text"] = "  Username: " + username
    goalLabel["text"] = "  Daily Goal: " + dailyGoal
    startLabel["text"] = "Welcome " + username

    profileData["name"] = username
    profileData["daily"] = dailyGoal
    profileData["counter"] = 1

    pickle_out = open("dict.pickle", "wb")
    pickle.dump(profileData, pickle_out)
    pickle_out.close()

# Practice Function
def submit(entry):
    global pracIndex
    global fullList
    global QsToday
    global dailyGoal

    if pracIndex == len(fullList) - 1:
        pracIndex = 0

    if entry != fullList[pracIndex]:
        wrong["fg"] = "red"
    else:
        pracIndex += 1
        QsToday += 1
        wrong["fg"] = "#80DEEA"
        displayWord["text"] = fullList[pracIndex]
        pracEntry.delete(0, END)
        if int(QsToday) >= int(dailyGoal):
            totalQ["text"] = "  Finished Today's Goal of: " + str(dailyGoal)


def skip():
    global pracIndex
    global fullList

    pracIndex += 1
    if pracIndex == len(fullList):
        pracIndex = 0
    displayWord["text"] = fullList[pracIndex]


# Alphabet Functions
def nextAlpha():
    global alpha_index
    global alphabets

    alpha_index += 1
    if alpha_index == 26:
        alpha_index = 0
    showAlpha["text"] = alphabets[alpha_index]

def backAlpha():
    global alpha_index
    global alphabets

    alpha_index -= 1
    if alpha_index == -1:
        alpha_index = 25
    showAlpha["text"] = alphabets[alpha_index]

def sound():
    global alpha_index
    global soundFiles
    winsound.PlaySound(soundFiles[alpha_index], winsound.SND_ASYNC)

# Short Word Functions
def nextShort():
    global short_index
    global shortWords

    short_index += 1
    if short_index == len(shortWords):
        short_index = 0
    showWordS["text"] = shortWords[short_index]

def backShort():
    global short_index
    global shortWords

    short_index -= 1
    if short_index == -1:
        short_index = len(shortWords) - 1
    showWordS["text"] = shortWords[short_index]


# Long Word Function
def nextLong():
    global long_index
    global longWords

    long_index += 1
    if long_index == len(longWords):
        long_index = 0
    showWordL["text"] = longWords[long_index]

def backLong():
    global long_index
    global longWords

    long_index -= 1
    if long_index == -1:
        long_index = len(longWords) - 1
    showWordL["text"] = longWords[long_index]

# Variables
username = ""
dailyGoal = 1
QsToday = 0
profileData = {"name": username, "daily": dailyGoal, "counter": 0}
error = 0

# Lists
alphabets = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
             "u", "v", "w", "x", "y", "z"]
alpha_index = 0

shortWords = ["a", "and", "away", "big", "blue", "can", "come", "down", "find", "for", "fun", "go", "help", "here",
              "I", "in", "is", "it", "jump", "small", "look", "make", "me", "my", "not", "one", "play", "up", "see"]
short_index = 0

longWords = ["world", "about", "again", "heart", "pizza", "month", "party", "apple", "earth", "money", "house", "watch",
             "badge", "chariot", "school", "envelope", "genius", "actual", "adults", "focus", "opponent", "proves"]
long_index = 0

soundFiles = ["a.wav", "b.wav", "c.wav", "d.wav", "e.wav", "f.wav", "g.wav", "h.wav", "i.wav", "j.wav", "k.wav",
              "l.wav", "m.wav", "n.wav", "o.wav", "p.wav", "q.wav", "r.wav", "s.wav", "t.wav", "u.wav", "v.wav",
              "w.wav", "x.wav", "y.wav", "z.wav"]

fullList = shortWords + longWords
pracIndex = 0

# Initialization
root = Tk()
root.geometry("800x600")

# Frames
startMenu = Frame(root, bg="#FFAB91")
profileFrame = Frame(root, bg="#E6EE9C")
practiceFrame = Frame(root, bg="#80DEEA")
learnMenu = Frame(root, bg="#73ffab")
learnFrameL = Frame(root, bg="#B39DDB")
learnFrameS = Frame(root, bg="#CCCBC8")
alphaFrame = Frame(root, bg="#FFE082")

for frame in (startMenu, profileFrame, practiceFrame, learnMenu, learnFrameL, alphaFrame, learnFrameS):
    frame.place(relx=0.025, rely=0.025, relwidth=0.95, relheight=0.95)

# Start Menu
startLabel = Label(startMenu, text="Welcome " + username, bg="#FFAB91", font=("Centaur", 37))
startLabel.place(relheight=0.2, relwidth=0.7, relx=0.15, rely=0.1)

profile_start = Button(startMenu, text="Profile", font=("Centaur",20), padx=95, command=lambda: swap(profileFrame))
profile_start.place(relheight=0.1, relwidth=0.3, relx=0.35, rely=0.30)

practice_start = Button(startMenu, text="Practice", font=("Centaur",20), padx=90, command=lambda: swap(practiceFrame))
practice_start.place(relheight=0.1, relwidth=0.3, relx=0.35, rely=0.45)

learn_start = Button(startMenu, text="Learn", font=("Centaur",20), padx=100, command=lambda: swap(learnMenu))
learn_start.place(relheight=0.1, relwidth=0.3, relx=0.35, rely=0.60)

# Profile Page
back_profile = Button(profileFrame, text="back", font=("Centaur", 15), command=lambda: swap(startMenu))
back_profile.place(relheight=0.07, relwidth=0.07, relx=0.91, rely=0.91)

userImg = PhotoImage(file="user.png")
profilePic = Label(profileFrame, image=userImg)
profilePic.place(relx=0.05, rely=0.08)

nameLabel = Label(profileFrame, text="  Username: " + username, font=("Centaur", 20), anchor="w")
nameLabel.place(relx=0.4, rely=0.12, relwidth=0.5)

goalLabel = Label(profileFrame, text="  Daily Goal: " + str(dailyGoal), font=("Centaur", 20), anchor="w")
goalLabel.place(relx=0.4, rely=0.22, relwidth=0.5)

totalQ = Label(profileFrame, text="  Questions Answered: " + str(QsToday), font=("Centaur", 20), anchor="w")
totalQ.place(relx=0.4, rely=0.32, relwidth=0.5)

edit = Button(profileFrame, text="Edit", font=("Centaur", 13), command=lambda: createEditor())
edit.place(relx=0.61, rely=0.42)

# Practice Page
back_practice = Button(practiceFrame, text="back", font=("Centaur", 15), command=lambda: swap(startMenu))
back_practice.place(relheight=0.07, relwidth=0.07, relx=0.91, rely=0.91)

wordTitle = Label(practiceFrame, text="WORD", font=("Centaur", 30), bg="#80DEEA")
wordTitle.place(relx=0.42, rely=0.1)

displayWord = Label(practiceFrame, font=("Centaur", 25), text=fullList[pracIndex])
displayWord.place(relx=0.33, rely=0.23, relwidth=0.35, relheight=0.1)

wrong = Label(practiceFrame, font=("Centaur", 30), text="Wrong", bg="#80DEEA", fg="#80DEEA")
wrong.place(relx=0.42, rely=0.75)

spellTitle = Label(practiceFrame, text="SPELL", font=("Centaur", 30), bg="#80DEEA")
spellTitle.place(relx=0.43, rely=0.37)

pracEntry = Entry(practiceFrame, font=("Centaur", 25))
pracEntry.place(relx=0.33, rely=0.5, relwidth=0.35, relheight=0.1)

prac_submit = Button(practiceFrame, text="Submit", font=("Centaur", 15), command=lambda: submit(pracEntry.get()))
prac_submit.place(relx=0.35, rely=0.64, relwidth=0.15)

prac_skip = Button(practiceFrame, text="Skip", font=("Centaur", 15), command=lambda: skip())
prac_skip.place(relx=0.56, rely=0.64, relwidth=0.1)

# Learn Menu
back_lmenu = Button(learnMenu, text="back", font=("Centaur", 15), command=lambda: swap(startMenu))
back_lmenu.place(relheight=0.07, relwidth=0.07, relx=0.91, rely=0.91)

short_lmenu = Button(learnMenu, text="Learn Short Words", font=("Centaur",22), command=lambda:swap(learnFrameS))
short_lmenu.place(relheight=0.1, relwidth=0.35, relx=0.33, rely=0.25)

long_lmenu = Button(learnMenu, text="Learn Long Words", font=("Centaur",22),  command=lambda:swap(learnFrameL))
long_lmenu.place(relheight=0.1, relwidth=0.35, relx=0.33, rely=0.45)

alpha_lmenu = Button(learnMenu, text="Learn Alphabets", font=("Centaur",22), command=lambda:swap(alphaFrame))
alpha_lmenu.place(relheight=0.1, relwidth=0.35, relx=0.33, rely=0.65)

# Learning Page Long
back_learnL = Button(learnFrameL, text="back", font=("Centaur", 15), command=lambda: swap(learnMenu))
back_learnL.place(relheight=0.07, relwidth=0.07, relx=0.91, rely=0.91)

learnTitleL = Label(learnFrameL, text="Learn to Read Long Words", font=("Centaur", 35), bg="#B39DDB")
learnTitleL.place(relx=0.2, rely=0.15)

showWordL = Label(learnFrameL, font=("Centaur", 45), text=longWords[0])
showWordL.place(relheight=0.3, relwidth=0.53, relx=0.25, rely=0.28)

learn_nextL = Button(learnFrameL, text="⇨", font=("Centaur", 30), command=lambda: nextLong())
learn_nextL.place(relx=0.67, rely=0.63, relheight=0.07)

learn_backL = Button(learnFrameL, text="⇦", font=("Centaur", 30), command=lambda: backLong())
learn_backL.place(relx=0.27, rely=0.63, relheight=0.07)

# Learning Page Short
back_learnS = Button(learnFrameS, text="back", font=("Centaur", 15), command=lambda: swap(learnMenu))
back_learnS.place(relheight=0.07, relwidth=0.07, relx=0.91, rely=0.91)

learnTitleS = Label(learnFrameS, text="Learn to Read Short Words", font=("Centaur", 35), bg="#CCCBC8")
learnTitleS.place(relx=0.2, rely=0.15)

showWordS = Label(learnFrameS, font=("Centaur", 45), text=shortWords[0])
showWordS.place(relheight=0.3, relwidth=0.53, relx=0.25, rely=0.28)

learn_nextS = Button(learnFrameS, text="⇨", font=("Centaur", 30), command=lambda: nextShort())
learn_nextS.place(relx=0.67, rely=0.63, relheight=0.07)

learn_backS = Button(learnFrameS, text="⇦", font=("Centaur", 30), command=lambda: backShort())
learn_backS.place(relx=0.27, rely=0.63, relheight=0.07)

# Alphabet Page
back_alpha = Button(alphaFrame, text="back", font=("Centaur", 15), command=lambda: swap(learnMenu))
back_alpha.place(relheight=0.07, relwidth=0.07, relx=0.91, rely=0.91)

alphaTitle = Label(alphaFrame, text="The Alphabets", font=("Centaur", 35), bg="#FFE082")
alphaTitle.place(relx=0.34, rely=0.1)

showAlpha = Label(alphaFrame, font=("Centaur", 55), text=alphabets[0])
showAlpha.place(relheight=0.35, relwidth=0.4, relx=0.31, rely=0.3)

alpha_next = Button(alphaFrame, text="Next", font=("Centaur", 18), command=lambda: nextAlpha())
alpha_next.place(relx=0.75, rely=0.44)

alpha_back = Button(alphaFrame, text="Back", font=("Centaur", 18), command=lambda: backAlpha())
alpha_back.place(relx=0.19, rely=0.44)

alpha_sound = Button(alphaFrame, text="Play Sound", font=("Centaur", 18), command=lambda: sound())
alpha_sound.place(relx=0.43, rely=0.68)

startMenu.tkraise()
root.mainloop()